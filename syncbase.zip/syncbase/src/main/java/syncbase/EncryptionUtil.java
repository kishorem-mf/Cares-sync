package syncbase;



public class EncryptionUtil {

	public static String decrypt(String inString) {
		final int strLength = inString.length() / 3;
		String resultString = "";
		int j = 0;
		int k = 3;
		for (int x = 0; x < strLength; x++) {
			final int i = Integer.parseInt(inString.substring(j, k));
			j = k;
			k += 3;
			resultString = String.valueOf(resultString) + (char) i;
		}
		return resultString;
	}

	public static String encrypt(String inString) {
		String resultString = "";
		byte b;
		int i;
		char[] arrayOfChar;
		for (i = (arrayOfChar = inString.toCharArray()).length, b = 0; b < i;) {
			final char c = arrayOfChar[b];
			final int j = c;
			resultString = String.valueOf(resultString) + String.format("%03d", Integer.valueOf(j));
			b++;
		}
		return resultString;
	}

	public static void main(String[] args)  {


	}

}
