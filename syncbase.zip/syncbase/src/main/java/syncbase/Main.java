package syncbase;

public class Main {
	public static void main(String[] args) {

		SalesforceConnector connector = new SalesforceConnector();
		try {
			connector.test();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
