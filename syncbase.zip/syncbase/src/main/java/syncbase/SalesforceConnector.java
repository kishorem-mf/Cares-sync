package syncbase;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Base64;
import java.util.Properties;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class SalesforceConnector {
	public void test() throws Exception {

	      // Get the input stream for the property file
        InputStream is = SalesforceConnector.class.getResourceAsStream("/app.properties");

		Properties appProps = new Properties();
        // Load the property file
		appProps.load(is);



		String accessToken = login(appProps.getProperty("clientId"), appProps.getProperty("clientSecret"),
				EncryptionUtil.decrypt(appProps.getProperty("userName")),
				EncryptionUtil.decrypt(appProps.getProperty("password")), appProps.getProperty("loginUrl"));

		execQuery(appProps.getProperty("apiUrl"), accessToken, "SELECT+Id+FROM+Trigger_table__c where Status__c='New'");

	}

	public static String login(final String clientId, final String clientSecret, final String userName,
			final String password, final String loginUrl) {

		String credentials = ((clientId + ":") + clientSecret);
		byte[] _encode = Base64.getEncoder().encode(credentials.getBytes());
		String encodedCredentials = new String(_encode);
		String requestBody = ((((((("grant_type=password&client_id=" + clientId) + "&client_secret=") + clientSecret)
				+ "&username=") + userName) + "&password=") + password);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", ("Basic " + encodedCredentials));
		HttpEntity<String> request = new HttpEntity<>(requestBody, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.<String>exchange(loginUrl, HttpMethod.POST, request,
				String.class);
		HttpStatusCode _statusCode = response.getStatusCode();

		if (_statusCode == HttpStatus.OK) {
			System.out.println("OAuth Authentication Success");
			String responseBody = response.getBody();
			return ((responseBody.split(",")[0]).split(":")[1]).replace("\"", "");
		} else {
			System.out.println("OAuth Authentication Failed");
			return null;
		}
	}

	private void execQuery(String apiUrl, String accessToken, String query) {
		// Using Access Token to make API request
		RestTemplate restTemplate = new RestTemplate();
		String request = apiUrl + "query?q=" + query;
		HttpHeaders apiHeaders = new HttpHeaders();
		apiHeaders.add("Authorization", "Bearer " + accessToken);
		HttpEntity<String> apiRequest = new HttpEntity<>(apiHeaders);

		// Making API request
		ResponseEntity<String> apiResponse = restTemplate.exchange(request, HttpMethod.GET, apiRequest, String.class);

		if (apiResponse.getStatusCode() == HttpStatus.OK) {
			System.out.println("API Response:");
			System.out.println(apiResponse.getBody());
		} else {

			System.out.println("API Request Failed");
			System.out.println(apiResponse.getStatusCode().toString());
			System.out.println(apiResponse.getBody());
		}
	}
}
