package syncbase;

import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Value;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;

public class KCLConsumer {

	// @Value("aws.access.key")
	// private String accessKey;
	//
	// @Value("aws.secret.key")
	// private String secretKey;

	private static String IPS_STREAM = "kds_aiee_npd_cares";
	private static String APPLICATION_NAME = "carescdc-5";
	private static String KINESIS_END_POINT = "kinesis.us-east-1.amazonaws.com";
	private static String DYNAMO_DB_END_POINT = "dynamodb.us-east-1.amazonaws.com";

	public void test() throws Exception {

		// Get the input stream for the property file
		InputStream is = SalesforceConnector.class.getResourceAsStream("/app.properties");

		Properties appProps = new Properties();
		// Load the property file
		appProps.load(is);

		String accessKey = appProps.getProperty("aws.access.key");
		String secretKey = appProps.getProperty("aws.secret.key");

		System.out.println(accessKey + "  " + secretKey);

		BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);

		KinesisClientLibConfiguration consumerConfig = new KinesisClientLibConfiguration(
				APPLICATION_NAME,
				IPS_STREAM,
				KINESIS_END_POINT,
				DYNAMO_DB_END_POINT,
				InitialPositionInStream.TRIM_HORIZON,
				new AWSStaticCredentialsProvider(awsCredentials),
				new AWSStaticCredentialsProvider(awsCredentials),
				new AWSStaticCredentialsProvider(awsCredentials),
				KinesisClientLibConfiguration.DEFAULT_FAILOVER_TIME_MILLIS,
				"carescdc-5",
				KinesisClientLibConfiguration.DEFAULT_MAX_RECORDS,
				KinesisClientLibConfiguration.DEFAULT_IDLETIME_BETWEEN_READS_MILLIS,
				KinesisClientLibConfiguration.DEFAULT_DONT_CALL_PROCESS_RECORDS_FOR_EMPTY_RECORD_LIST,
				KinesisClientLibConfiguration.DEFAULT_PARENT_SHARD_POLL_INTERVAL_MILLIS,
				KinesisClientLibConfiguration.DEFAULT_SHARD_SYNC_INTERVAL_MILLIS,
				KinesisClientLibConfiguration.DEFAULT_CLEANUP_LEASES_UPON_SHARDS_COMPLETION,
				new ClientConfiguration(),
				new ClientConfiguration(),
				new ClientConfiguration(),
				KinesisClientLibConfiguration.DEFAULT_TASK_BACKOFF_TIME_MILLIS,
				KinesisClientLibConfiguration.DEFAULT_METRICS_BUFFER_TIME_MILLIS,
				KinesisClientLibConfiguration.DEFAULT_METRICS_MAX_QUEUE_SIZE,
				KinesisClientLibConfiguration.DEFAULT_VALIDATE_SEQUENCE_NUMBER_BEFORE_CHECKPOINTING,
				Regions.US_EAST_1.getName(),
				KinesisClientLibConfiguration.DEFAULT_SHUTDOWN_GRACE_MILLIS,
				KinesisClientLibConfiguration.DEFAULT_DDB_BILLING_MODE,
				null,
				0,
				0,
				0);
		final Worker worker = new Worker.Builder()
				.recordProcessorFactory(new IpProcessorFactory())
				.config(consumerConfig)
				.build();
		try {
			worker.run();
		} catch (Throwable t) {
			System.err.println("Caught throwable while processing data.");
			t.printStackTrace();
		}
	}
}
