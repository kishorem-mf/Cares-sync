package cli.util;


import com.google.common.base.Objects;
import com.google.common.collect.Lists;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.sforce.async.BulkConnection;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.bind.XmlObject;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.eclipse.xtext.xbase.lib.ArrayExtensions;
import org.eclipse.xtext.xbase.lib.Conversions;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.ListExtensions;
import org.eclipse.xtext.xbase.lib.StringExtensions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@SuppressWarnings("all")
public class CommonUtil {
  private static Logger logger = LoggerFactory.getLogger(CommonUtil.class);

  public static String dateFormatString = "yyyy-MM-dd";

  public static SimpleDateFormat dateFormat = new SimpleDateFormat(CommonUtil.dateFormatString);

  public static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss");

  public static SimpleDateFormat dateTimeMillisFormat = new SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss.SSS");

  public static SimpleDateFormat mockDateFormat = new SimpleDateFormat("M/d/yyyy");

  public static String timeZoneSting = "America/Los_Angeles";

  public static TimeZone timeZone = TimeZone.getTimeZone(CommonUtil.timeZoneSting);

  public static String dateTimeMillisFormatString = "yyyy-MM-dd\'T\'HH:mm:ss.SSSXXX";

  public static DateTimeFormatter dateTimeMillisformatter = DateTimeFormatter.ofPattern(CommonUtil.dateTimeMillisFormatString);

  public static /* PartnerConnection */Object connect(final String username, final String password, final String serviceEndPoint) throws IOException, ConnectionException {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method getPartnerConnection(String, String, String) from the type CommonUtil refers to the missing type PartnerConnection");
  }

  public static /* MetadataConnection */Object metadataConnect(final String username, final String password, final String authEndPoint, final String serviceEndPoint) throws IOException, ConnectionException {
    throw new Error("Unresolved compilation problems:"
      + "\nMetadataConnection cannot be resolved."
      + "\nThe method getMetadataConnection(String, String, String, String) from the type CommonUtil refers to the missing type LoginResult"
      + "\ngetMetadataServerUrl cannot be resolved"
      + "\ngetSessionId cannot be resolved");
  }

  public static BulkConnection bulkConnect(final String username, final String password, final String authEndPoint) throws IOException, ConnectionException {
    CommonUtil.logger.info("Creating BulkConnection for {}", authEndPoint);
    final BulkConnection connection = CommonUtil.getBulkConnection(
      EncryptionUtil.decrypt(username), 
      EncryptionUtil.decrypt(password), authEndPoint);
    return connection;
  }

  public static /* LoginResult */Object getMetadataConnection(final String userName, final String password, final String authEndpoint, final String serviceEndpoint) throws ConnectionException {
    throw new Error("Unresolved compilation problems:"
      + "\nEnterpriseConnection cannot be resolved."
      + "\nlogin cannot be resolved");
  }

  public static BulkConnection getBulkConnection(final String userName, final String password, final String endPoint) throws ConnectionException {
    throw new Error("Unresolved compilation problems:"
      + "\nPartnerConnection cannot be resolved.");
  }

  public static /* PartnerConnection */Object getPartnerConnection(final String userName, final String password, final String endPoint) throws ConnectionException {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method or field Connector is undefined"
      + "\nnewConnection cannot be resolved");
  }

  public static String login(final String clientId, final String clientSecret, final String duserName, final String dpassword, final String loginUrl) {
    try {
      CommonUtil.logger.info("Performing login for {}", loginUrl);
      final String username = EncryptionUtil.decrypt(duserName);
      final String password = EncryptionUtil.decrypt(dpassword);
      String credentials = ((clientId + ":") + clientSecret);
      byte[] _encode = Base64.getEncoder().encode(credentials.getBytes());
      String encodedCredentials = new String(_encode);
      String requestBody = ((((((("grant_type=password&client_id=" + clientId) + "&client_secret=") + clientSecret) + 
        "&username=") + username) + "&password=") + password);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
      headers.add("Authorization", ("Basic " + encodedCredentials));
      HttpEntity<String> request = new HttpEntity<String>(requestBody, headers);
      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> response = restTemplate.<String>exchange(loginUrl, HttpMethod.POST, request, String.class);
      HttpStatusCode _statusCode = response.getStatusCode();
      boolean _equals = Objects.equal(_statusCode, HttpStatus.OK);
      if (_equals) {
        CommonUtil.logger.info("OAuth Authentication Success");
        String responseBody = response.getBody();
        return ((responseBody.split(",")[0]).split(":")[1]).replace("\"", "");
      } else {
        CommonUtil.logger.info("OAuth Authentication Failed");
        CommonUtil.logger.info(response.getStatusCode().toString());
        CommonUtil.logger.info(response.getBody());
        throw new Exception("OAuth Authentication Failed");
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }

  public static List<String> getValues(final CSVRecord row) {
    ArrayList<String> values = Lists.<String>newArrayList();
    for (int i = 0; (i < row.size()); i++) {
      values.add(row.get(i));
    }
    return values;
  }

  public static void validateDate(final String name, final Date dateInst, final CSVRecord record) {
    boolean _after = dateInst.after(Calendar.getInstance().getTime());
    if (_after) {
      long _recordNumber = record.getRecordNumber();
      String _plus = ((("Future date not allowed in " + name) + " Record:") + Long.valueOf(_recordNumber));
      throw new RuntimeException(_plus);
    }
  }

  public static void setValues(final List<String> values, final String name, final CSVRecord record, final int index, final boolean validate, final String[] dateFormat, final String[] dateTimeFormat, final String[] dateTimeMillisFormat, final boolean formatted) {
    final String value = record.get(index);
    boolean _isInvalidValue = CommonUtil.isInvalidValue(value);
    if (_isInvalidValue) {
      values.set(index, "");
      return;
    }
    ZonedDateTime t = null;
    boolean _matched = false;
    boolean _contains = ArrayExtensions.contains(dateTimeMillisFormat, name);
    if (_contains) {
      _matched=true;
      if (formatted) {
        t = LocalDateTime.parse(value).atZone(ZoneId.of(CommonUtil.timeZoneSting));
      } else {
        t = LocalDateTime.parse(CommonUtil.dateTimeMillisFormat(value)).atZone(ZoneId.of(CommonUtil.timeZoneSting));
      }
      values.set(index, CommonUtil.dateTimeMillisformatter.format(t));
    }
    if (!_matched) {
      boolean _contains_1 = ArrayExtensions.contains(dateTimeFormat, name);
      if (_contains_1) {
        _matched=true;
        if (formatted) {
          t = LocalDateTime.parse(value).atZone(ZoneId.of(CommonUtil.timeZoneSting));
        } else {
          t = LocalDateTime.parse(CommonUtil.dateTimeFormat(value)).atZone(ZoneId.of(CommonUtil.timeZoneSting));
        }
        values.set(index, CommonUtil.dateTimeMillisformatter.format(t));
      }
    }
    if (!_matched) {
      boolean _contains_2 = ArrayExtensions.contains(dateFormat, name);
      if (_contains_2) {
        _matched=true;
        if (formatted) {
          values.set(index, value);
        } else {
          values.set(index, CommonUtil.dateFormat(value));
        }
      }
    }
    if (!_matched) {
      boolean _equals = name.equals("Patient_ID__c");
      if (_equals) {
        _matched=true;
        int _length = value.length();
        boolean _greaterThan = (_length > 20);
        if (_greaterThan) {
          values.set(index, value.substring(0, 20));
        } else {
          values.set(index, value);
        }
      }
    }
    if (!_matched) {
      boolean _equals_1 = name.equals("Patient_Race__c");
      if (_equals_1) {
        _matched=true;
        if (((value == null) || value.trim().equals(""))) {
          values.set(index, "");
        } else {
          final Function1<String, String> _function = (String race) -> {
            return StringExtensions.toFirstUpper(race.trim());
          };
          values.set(index, IterableExtensions.join(ListExtensions.<String, String>map(((List<String>)Conversions.doWrapArray(value.split(";"))), _function), ";"));
        }
      }
    }
    if (!_matched) {
      values.set(index, value);
    }
  }

  public static void setValue(final /* SObject */Object sObject, final String name, final CSVRecord record, final int index, final boolean validate, final String[] dateFormat, final String[] dateTimeFormat, final String[] dateTimeMillisFormat, final boolean formatted) {
    throw new Error("Unresolved compilation problems:"
      + "\nThe method setDateValue(boolean, String, Date, CSVRecord, SObject) from the type CommonUtil refers to the missing type SObject"
      + "\nThe method setDateValue(boolean, String, Date, CSVRecord, SObject) from the type CommonUtil refers to the missing type SObject"
      + "\nThe method setDateValue(boolean, String, Date, CSVRecord, SObject) from the type CommonUtil refers to the missing type SObject"
      + "\nsetField cannot be resolved"
      + "\nsetField cannot be resolved"
      + "\nsetField cannot be resolved"
      + "\nsetField cannot be resolved"
      + "\nsetField cannot be resolved");
  }

  public static String cipher(final String input) {
    String out = "";
    for (int i = 0; (i < input.length()); i++) {
      {
        char c = input.charAt(i);
        boolean _matched = false;
        char _charAt = "1".charAt(0);
        if (Objects.equal(c, _charAt)) {
          _matched=true;
          out = (out + "DO");
        }
        if (!_matched) {
          char _charAt_1 = "2".charAt(0);
          if (Objects.equal(c, _charAt_1)) {
            _matched=true;
            out = (out + "RE");
          }
        }
        if (!_matched) {
          char _charAt_2 = "3".charAt(0);
          if (Objects.equal(c, _charAt_2)) {
            _matched=true;
            out = (out + "MI");
          }
        }
        if (!_matched) {
          char _charAt_3 = "4".charAt(0);
          if (Objects.equal(c, _charAt_3)) {
            _matched=true;
            out = (out + "FA");
          }
        }
        if (!_matched) {
          char _charAt_4 = "5".charAt(0);
          if (Objects.equal(c, _charAt_4)) {
            _matched=true;
            out = (out + "SO");
          }
        }
        if (!_matched) {
          char _charAt_5 = "6".charAt(0);
          if (Objects.equal(c, _charAt_5)) {
            _matched=true;
            out = (out + "LA");
          }
        }
        if (!_matched) {
          char _charAt_6 = "7".charAt(0);
          if (Objects.equal(c, _charAt_6)) {
            _matched=true;
            out = (out + "TI");
          }
        }
        if (!_matched) {
          char _charAt_7 = "8".charAt(0);
          if (Objects.equal(c, _charAt_7)) {
            _matched=true;
            out = (out + "NU");
          }
        }
        if (!_matched) {
          char _charAt_8 = "9".charAt(0);
          if (Objects.equal(c, _charAt_8)) {
            _matched=true;
            out = (out + "KA");
          }
        }
        if (!_matched) {
          char _charAt_9 = "0".charAt(0);
          if (Objects.equal(c, _charAt_9)) {
            _matched=true;
            out = (out + "EX");
          }
        }
        if (!_matched) {
          out = (out + " EI");
        }
      }
    }
    return out;
  }

  protected static XmlObject setDateValue(final boolean validate, final String name, final Date dateInst, final CSVRecord record, final /* SObject */Object sObject) {
    throw new Error("Unresolved compilation problems:"
      + "\nsetField cannot be resolved");
  }

  public static String dateTimeMillisFormat(final String dateString) {
    boolean _isInvalidValue = CommonUtil.isInvalidValue(dateString);
    if (_isInvalidValue) {
      return "";
    }
    String _substring = dateString.substring(5, 9);
    String _plus = (_substring + "-");
    String _get = Constants.months.get(dateString.substring(2, 5));
    String _plus_1 = (_plus + _get);
    String _plus_2 = (_plus_1 + "-");
    String _substring_1 = dateString.substring(0, 2);
    String _plus_3 = (_plus_2 + _substring_1);
    String _plus_4 = (_plus_3 + "T");
    String _substring_2 = dateString.substring(10);
    return (_plus_4 + _substring_2);
  }

  public static String dateFormat(final String dateString) {
    boolean _isInvalidValue = CommonUtil.isInvalidValue(dateString);
    if (_isInvalidValue) {
      return "";
    }
    int _length = dateString.length();
    boolean _lessThan = (_length < 8);
    if (_lessThan) {
      return "";
    }
    String _substring = dateString.substring(0, 4);
    String _plus = (_substring + "-");
    String _substring_1 = dateString.substring(4, 6);
    String _plus_1 = (_plus + _substring_1);
    String _plus_2 = (_plus_1 + "-");
    String _substring_2 = dateString.substring(6, 8);
    return (_plus_2 + _substring_2);
  }

  public static String dateTimeFormat(final String dateString) {
    boolean _isInvalidValue = CommonUtil.isInvalidValue(dateString);
    if (_isInvalidValue) {
      return "";
    }
    int _length = dateString.length();
    boolean _lessThan = (_length < 8);
    if (_lessThan) {
      return "";
    }
    int _length_1 = dateString.length();
    boolean _equals = (_length_1 == 14);
    if (_equals) {
      String _substring = dateString.substring(0, 4);
      String _plus = (_substring + "-");
      String _substring_1 = dateString.substring(4, 6);
      String _plus_1 = (_plus + _substring_1);
      String _plus_2 = (_plus_1 + "-");
      String _substring_2 = dateString.substring(6, 8);
      String _plus_3 = (_plus_2 + _substring_2);
      String _plus_4 = (_plus_3 + 
        "T");
      String _substring_3 = dateString.substring(8, 10);
      String _plus_5 = (_plus_4 + _substring_3);
      String _plus_6 = (_plus_5 + ":");
      String _substring_4 = dateString.substring(10, 12);
      String _plus_7 = (_plus_6 + _substring_4);
      String _plus_8 = (_plus_7 + ":");
      String _substring_5 = dateString.substring(12, 14);
      return (_plus_8 + _substring_5);
    } else {
      int _length_2 = dateString.length();
      boolean _greaterEqualsThan = (_length_2 >= 8);
      if (_greaterEqualsThan) {
        String _substring_6 = dateString.substring(0, 4);
        String _plus_9 = (_substring_6 + "-");
        String _substring_7 = dateString.substring(4, 6);
        String _plus_10 = (_plus_9 + _substring_7);
        String _plus_11 = (_plus_10 + "-");
        String _substring_8 = dateString.substring(6, 8);
        return (_plus_11 + _substring_8);
      } else {
        throw new RuntimeException(("Invalid date Format:" + dateString));
      }
    }
  }

  protected static boolean isInvalidValue(final String value) {
    return ((((((value == null) || value.trim().equals("")) || value.trim().equals("0000")) || value.trim().equals("0")) || 
      value.trim().equals("ERROR")) || value.trim().equals("NULL"));
  }

  public static Session getSFTPConnectionSession(final String userName, final String password, final String sftphost, final int port) {
    try {
      final Properties props = new Properties();
      props.put("StrictHostKeyChecking", "no");
      final JSch jsch = new JSch();
      Session session = null;
      session = jsch.getSession(EncryptionUtil.decrypt(userName), sftphost, port);
      session.setConfig(props);
      session.setPassword(EncryptionUtil.decrypt(password));
      session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
      session.connect();
      return session;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
