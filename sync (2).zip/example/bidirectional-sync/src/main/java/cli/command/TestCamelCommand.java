package cli.command;

import java.io.File;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.sforce.async.BulkConnection;


import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.salesforce.SalesforceEndpointConfig;
import org.apache.camel.component.salesforce.SalesforceLoginConfig;
import org.apache.camel.component.salesforce.internal.PayloadFormat;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.salesforce.dto.QueryRecordsAccount;

@Component
@Command(name = "testcamel", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class TestCamelCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(TestCamelCommand.class);
	static org.apache.camel.main.Main main;

	@Override
	public Integer call() {
		logger.info("cli testcamel was called");

		try {
			
			main = new org.apache.camel.main.Main();
			main.configure().addRoutesBuilder(new ConsoleRoute());
			main.run();

		} catch (final Exception cex) {
			logger.error("cli testcamel failed", cex);
			return 34;
		}

		return 0;
	}

	public class ConsoleRoute extends RouteBuilder {

		@Override
		public void configure() throws Exception {

	        // Camel route
		   	from("timer:hello?period=5000")
            .to("salesforce:query?sObjectQuery=SELECT+Id,Name+FROM+Account&format=JSON&sObjectClass=" + QueryRecordsAccount.class.getName())
            .log("${body}")
        	.to("stream:out");
			
		}

	}
}
