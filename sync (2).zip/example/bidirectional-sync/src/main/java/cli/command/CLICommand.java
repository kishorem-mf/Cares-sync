package cli.command;

import java.util.concurrent.Callable;

import org.springframework.stereotype.Component;

import picocli.CommandLine.Command;

@Component
@Command(name = "cli", version = "CLI V 1.0", mixinStandardHelpOptions = true, subcommands = {
		BulkExportCommand.class, 
		BulkLoadCommand.class, 
		TestCamelCommand.class,
		TestConnectionCommand.class, 
		TestRestAPICommand.class,

 })
public class CLICommand implements Callable<Integer> {
	@Override
	public Integer call() {
		return 23;
	}
}