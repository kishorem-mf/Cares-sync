package cli.command;

import java.io.File;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.sforce.async.BulkConnection;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "testrestapi", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class TestRestAPICommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(TestRestAPICommand.class);
	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File authConfig;

	private String username;
	private String password;
	private String clientId;
	private String clientSecret;
	private String oauthUrl;
	private String restUrl;


	String accessToken;

	@Override
	public Integer call() {
		logger.info("cli testrestapi was called with input {}", this.authConfig.toPath());

		try {
			this.configureAuth();

			this.accessToken=CommonUtil.login(clientId, clientSecret, username, password, oauthUrl);
			testRestAPI(accessToken);

		} catch (final Exception cex) {
			logger.error("cli testrestapi failed", cex);
			return 34;
		}

		return 0;
	}
	
	private  void testRestAPI( String accessToken) {
		// Using Access Token to make API request
	    RestTemplate restTemplate = new RestTemplate();
		String apiUrl = "https://asg-cwstso--caresdemo.sandbox.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id+FROM+Trigger_table__c where Status__c='New'";
		HttpHeaders apiHeaders = new HttpHeaders();
		apiHeaders.add("Authorization", "Bearer " + accessToken);
		HttpEntity<String> apiRequest = new HttpEntity<>(apiHeaders);

		// Making API request
		ResponseEntity<String> apiResponse = restTemplate.exchange(apiUrl, HttpMethod.GET, apiRequest, String.class);

		if (apiResponse.getStatusCode() == HttpStatus.OK) {
			logger.info("API Response:");
			logger.info(apiResponse.getBody());
		} else {

			logger.info("API Request Failed");
			logger.info(apiResponse.getStatusCode().toString());
			logger.info(apiResponse.getBody());
		}
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
				.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
						.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.clientId = config.getString("clientId");
		this.clientSecret = config.getString("clientSecret");
		this.oauthUrl = config.getString("oauthUrl");
		this.restUrl = config.getString("restUrl");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("oauthUrl:" + this.oauthUrl);
		logger.info("clientId:" + this.clientId);
		logger.info("clientSecret:" + this.clientSecret);
		logger.info("restUrl:" + this.restUrl);

	}

}
