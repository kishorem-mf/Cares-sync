package cli.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.async.AsyncApiException;
import com.sforce.async.BatchInfo;
import com.sforce.async.BatchStateEnum;
import com.sforce.async.BulkConnection;
import com.sforce.async.CSVReader;
import com.sforce.async.ContentType;
import com.sforce.async.JobInfo;
import com.sforce.async.JobStateEnum;
import com.sforce.async.OperationEnum;
import com.sforce.ws.ConnectionException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "bulkload", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class BulkLoadCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(BulkLoadCommand.class);

	public static String getCurrentDate() {
		return Instant.now().atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_LOCAL_DATE);
	}

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	private String inputdatafile;
	private String objecliype;
	private String resultfile;

	BulkConnection bulkConnection;

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;
	
	@Option(names = { "-d", "--delete" }, description = "Hard delete")
	private boolean hardDelete =false;

	private void awaitCompletion(BulkConnection connection, JobInfo job, List<BatchInfo> batchInfoList)
			throws AsyncApiException {
		long sleepTime = 0L;
		final Set<String> incomplete = new HashSet<>();
		for (final BatchInfo bi : batchInfoList) {
			incomplete.add(bi.getId());
		}
		while (!incomplete.isEmpty()) {
			try {
				Thread.sleep(sleepTime);
			} catch (final InterruptedException e) {
			}
			logger.info("Awaiting results..." + incomplete.size());
			sleepTime = 10000L;
			final BatchInfo[] statusList = connection.getBatchInfoList(job.getId()).getBatchInfo();
			for (final BatchInfo b : statusList) {
				if ((b.getState() == BatchStateEnum.Completed) || (b.getState() == BatchStateEnum.Failed)) {
					if (incomplete.remove(b.getId())) {
						logger.info("BATCH STATUS:\n" + b);
					}
				}
			}
		}
	}

	@Override
	public Integer call() {
		logger.info("cli export was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();
			this.bulkConnection = CommonUtil.bulkConnect(this.username, this.password, this.serviceEndPoint);
			this.loadBulkData();

		} catch (final Exception cex) {
			logger.error("cli export failed", cex);
			return 34;
		}

		return 0;
	}

	/**
	 * Gets the results of the operation and checks for errors.
	 */
	private void checkResults(BulkConnection connection, JobInfo job, List<BatchInfo> batchInfoList)
			throws AsyncApiException, IOException {
		// batchInfoList was populated when batches were created and submitted
		for (final BatchInfo b : batchInfoList) {
			final CSVReader rdr = new CSVReader(connection.getBatchResultStream(job.getId(), b.getId()));
			final String resultFile = this.resultfile + b.getId() + ".csv";
			logger.info("Writing Results to:{} ", resultFile);
			final BufferedWriter writer = Files.newBufferedWriter(Paths.get(resultFile));
			final CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT);

			List<String> row;

			final List<String> resultHeader = rdr.nextRecord();
			final int resultCols = resultHeader.size();

			while ((row = rdr.nextRecord()) != null) {
				csvPrinter.printRecord(row);
				final Map<String, String> resultInfo = new HashMap<>();
				for (int i = 0; i < resultCols; i++) {
					resultInfo.put(resultHeader.get(i), row.get(i));
				}
				final boolean success = Boolean.valueOf(resultInfo.get("Success"));
				final boolean created = Boolean.valueOf(resultInfo.get("Created"));
				final String id = resultInfo.get("Id");
				final String error = resultInfo.get("Error");
				if (success && created) {
					if (logger.isDebugEnabled()) {
						logger.debug("Created row with id " + id);
					}
				} else if (!success) {
					logger.info("Failed with error: " + error);
				}
			}

			csvPrinter.close();
		}
	}

	private void closeJob(BulkConnection connection, String jobId) throws AsyncApiException {
		final JobInfo job = new JobInfo();
		job.setId(jobId);
		job.setState(JobStateEnum.Closed);
		connection.updateJob(job);
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.resultfile = config.getString("resultfile");
		this.inputdatafile = config.getString("inputdata");
		this.objecliype = config.getString("objecliype");

	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private void createBatch(FileOutputStream tmpOut, File tmpFile, List<BatchInfo> batchInfos,
			BulkConnection connection, JobInfo jobInfo) throws IOException, AsyncApiException {
		tmpOut.flush();
		tmpOut.close();
		final FileInputStream tmpInputStream = new FileInputStream(tmpFile);
		try {
			final BatchInfo batchInfo = connection.createBatchFromStream(jobInfo, tmpInputStream);
			logger.info(batchInfo.toString());
			batchInfos.add(batchInfo);

		} finally {
			tmpInputStream.close();
		}
	}

	private List<BatchInfo> createBatchesFromCSVFile(BulkConnection connection, JobInfo jobInfo, String csvFileName)
			throws IOException, AsyncApiException {
		final List<BatchInfo> batchInfos = new ArrayList<>();
		final BufferedReader rdr = new BufferedReader(new InputStreamReader(new FileInputStream(csvFileName)));
		// read the CSV header row
		final byte[] headerBytes = (rdr.readLine() + "\n").getBytes("UTF-8");
		final int headerBytesLength = headerBytes.length;
		final File tmpFile = File.createTempFile("bulkAPIInsert", ".csv");

		// Split the CSV file into multiple batches
		try {
			FileOutputStream tmpOut = new FileOutputStream(tmpFile);
			final int maxBytesPerBatch = 10000000; // 10 million bytes per batch
			final int maxRowsPerBatch = 10000; // 10 thousand rows per batch
			int currentBytes = 0;
			int currentLines = 0;
			String nextLine;
			while ((nextLine = rdr.readLine()) != null) {
				final byte[] bytes = (nextLine + "\n").getBytes("UTF-8");
				// Create a new batch when our batch size limit is reached
				if (((currentBytes + bytes.length) > maxBytesPerBatch) || (currentLines > maxRowsPerBatch)) {
					this.createBatch(tmpOut, tmpFile, batchInfos, connection, jobInfo);
					currentBytes = 0;
					currentLines = 0;
				}
				if (currentBytes == 0) {
					tmpOut = new FileOutputStream(tmpFile);
					tmpOut.write(headerBytes);
					currentBytes = headerBytesLength;
					currentLines = 1;
				}
				tmpOut.write(bytes);
				currentBytes += bytes.length;
				currentLines++;
			}
			// Finished processing all rows
			// Create a final batch for any remaining data
			if (currentLines > 1) {
				this.createBatch(tmpOut, tmpFile, batchInfos, connection, jobInfo);
			}
		} finally {
			tmpFile.delete();
		}
		return batchInfos;
	}

	private JobInfo createJob(String sobjecliype, BulkConnection connection) throws AsyncApiException {
		JobInfo job = new JobInfo();
		job.setObject(sobjecliype);
		job.setOperation(OperationEnum.insert);
		job.setContentType(ContentType.CSV);
		job = connection.createJob(job);
		logger.info(job.toString());
		return job;
	}

	public void loadBulkData() throws AsyncApiException, ConnectionException, IOException {

		final JobInfo job = this.createJob(this.objecliype, this.bulkConnection);
		final List<BatchInfo> batchInfoList = this.createBatchesFromCSVFile(this.bulkConnection, job,
				this.inputdatafile);
		this.closeJob(this.bulkConnection, job.getId());
		this.awaitCompletion(this.bulkConnection, job, batchInfoList);
		this.checkResults(this.bulkConnection, job, batchInfoList);
	}

}
