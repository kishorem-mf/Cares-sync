package syncbase;

import java.io.InputStream;
import java.util.Base64;
import java.util.Properties;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class SalesforceConnector {
	String accessToken;
	String clientId;
	String clientSecret;
	String userName;
	String password;
	String loginUrl;
	String apiUrl;

	private void init() throws Exception {

		InputStream is = SalesforceConnector.class.getResourceAsStream("/app.properties");

		Properties appProps = new Properties();
		appProps.load(is);
		
		this.clientId = appProps.getProperty("clientId");
		this.clientSecret = appProps.getProperty("clientSecret");
		this.userName = EncryptionUtil.decrypt(appProps.getProperty("userName"));
		this.password = EncryptionUtil.decrypt(appProps.getProperty("password"));
		this.loginUrl = appProps.getProperty("loginUrl");
		this.apiUrl = appProps.getProperty("apiUrl");

	}

	public void testQuery(String query) throws Exception {

		this.init();
		this.login();
		this.execQuery(query);
	}

	private void login() {

		String credentials = ((clientId + ":") + clientSecret);
		byte[] _encode = Base64.getEncoder().encode(credentials.getBytes());
		String encodedCredentials = new String(_encode);
		String requestBody = ((((((("grant_type=password&client_id=" + clientId) + "&client_secret=") + clientSecret)
				+ "&username=") + userName) + "&password=") + password);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization", ("Basic " + encodedCredentials));
		HttpEntity<String> request = new HttpEntity<>(requestBody, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.<String>exchange(loginUrl, HttpMethod.POST, request,
				String.class);

		if (response.getStatusCode()== HttpStatus.OK) {
			System.out.println("OAuth Authentication Success");
			String responseBody = response.getBody();
			this.accessToken = ((responseBody.split(",")[0]).split(":")[1]).replace("\"", "");
		} else {
			System.out.println("OAuth Authentication Failed");
			this.accessToken = null;
		}
	}

	private void execQuery(String query) {
		// Using Access Token to make API request
		RestTemplate restTemplate = new RestTemplate();
		String request = apiUrl + "query?q=" + query;
		HttpHeaders apiHeaders = new HttpHeaders();
		apiHeaders.add("Authorization", "Bearer " + accessToken);
		HttpEntity<String> apiRequest = new HttpEntity<>(apiHeaders);

		// Making API request
		ResponseEntity<String> apiResponse = restTemplate.exchange(request, HttpMethod.GET, apiRequest, String.class);

		if (apiResponse.getStatusCode() == HttpStatus.OK) {
			System.out.println("API Response:");
			System.out.println(apiResponse.getBody());
		} else {
			System.out.println("API Request Failed");
			System.out.println(apiResponse.getStatusCode().toString());
			System.out.println(apiResponse.getBody());
		}
	}
}
