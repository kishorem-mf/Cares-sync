package syncbase;

public class Main {
	public static void main(String[] args) {

		SalesforceConnector connector = new SalesforceConnector();
		try {
			connector.testQuery("SELECT+Id+FROM+Trigger_table__c where Status__c='New'");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
