package cli.command;

public class LoadResultError {
	String errorCode;
	String errorMessage;
	long recordNumber;

	public String getErrorCode() {
		return this.errorCode;
	}

	public String getErrorMessage() {
		return this.errorMessage;
	}

	public long getRecordNumber() {
		return this.recordNumber;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setRecordNumber(long recordNumber) {
		this.recordNumber = recordNumber;
	}
}
