package cli.command;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.DeleteResult;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "delete", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class DeleteCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(DeleteCommand.class);



	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	@Option(names = { "-o", "--output" }, description = "Output Directory", required = true)
	private File outputFile;
	
	@Option(names = { "-k", "--chunk" }, description = "Number of records in chunks")
	private final Integer chunk = 200;

	PartnerConnection connection;

	private String[] objects;

	private String[][] objectsValues;
	private String[] recordTypeIds;

	@Override
	public Integer call() {
		logger.info("cli delete was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();
			this.connection = CommonUtil.connect(this.username, this.password, this.serviceEndPoint);
			this.recordTypeIds = new String[this.objectsValues.length];
			for (int i = 0; i < this.objectsValues.length; i++) {
				String developerName = null;
				String objecliype = null;
				objecliype = this.objectsValues[i][0];
				if (this.objectsValues[i].length == 2) {
					developerName = this.objectsValues[i][1];
				}
				this.recordTypeIds[i] = this.getRecordTypeId(developerName, objecliype);
				this.deleteSObjects(objecliype, this.recordTypeIds[i]);
			}

		} catch (final Exception cex) {
			logger.error("cli delete failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.objects = config.getStringArray("objects");
		this.objectsValues = new String[this.objects.length][2];

		for (int i = 0; i < this.objects.length; i++) {
			logger.info("objects:" + this.objects[i]);
			this.objectsValues[i] = config.getStringArray(this.objects[i]);
			logger.info("objectsValues:" + this.objectsValues[i]);
		}
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private void deleteSObjects(ArrayList<String> toDelete) throws ConnectionException {

		final String[] arr = new String[toDelete.size()];
		logger.info("Deleting {}:", arr.length);

		final DeleteResult[] results = this.connection.delete(toDelete.toArray(arr));

		for (int j = 0; j < results.length; j++) {
			// write results to CSV file

			if (results[j].isSuccess()) {
				logger.debug("SObject Deleted with an ID of: " + results[j].getId());
			} else {
				for (int i = 0; i < results[j].getErrors().length; i++) {
					final com.sforce.soap.partner.Error err = results[j].getErrors()[i];
					logger.error("Errors were found on item {} Error code is: {} Error message: {}", j,
							err.getStatusCode(), err.getMessage());

				}
			}
		}

	}

	private void deleteSObjects(String objecliype, String recordTypeId)
			throws ConnectionException, IOException, SQLException {

		logger.info("Deleting {}:{}", objecliype, recordTypeId);

		String query = null;
		if (recordTypeId != null) {
			query = String.format("Select id from %s where RecordTypeId='%s'", objecliype, recordTypeId);
		} else {
			query = String.format("Select id from %s", objecliype);
		}
		logger.info("Query :{}", query);

		for (int r = 0; r < 2; r++) {
			final QueryResult qr = this.connection.query(query);
			final SObject[] records = qr.getRecords();
			logger.info("Processing {}:  Records", records.length);

			ArrayList<String> toDelete = new ArrayList<>();

			for (int i = 0; i < records.length; i++) {
				toDelete.add(records[i].getId());

				if (((i + 1) % this.chunk) == 0) {
					this.deleteSObjects(toDelete);
					toDelete = new ArrayList<>();
				}

				if ((i % 1000) == 0) {
					logger.info("Processed {}:", i);
				}
			}

			this.deleteSObjects(toDelete);
		}

	}

	private String getRecordTypeId(String developerName, String objecliype) throws ConnectionException {
		if ((developerName != null) && (objecliype != null)) {
			final QueryResult qr = this.connection
					.query(String.format("SELECT Id  FROM RecordType where DeveloperName='%s' and SObjecliype ='%s'",
							developerName, objecliype));
			final SObject[] records = qr.getRecords();
			if (records.length != 0) {
				return records[0].getId();
			}
		}
		return null;
	}
}
