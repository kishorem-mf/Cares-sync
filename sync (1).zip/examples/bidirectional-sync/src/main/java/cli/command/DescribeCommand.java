package cli.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.DescribeSObjectResult;
import com.sforce.soap.partner.Error;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.PicklistEntry;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.SaveResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;
import com.sforce.soap.partner.Field;
import com.sforce.soap.partner.FieldType;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "describe", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class DescribeCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(DescribeCommand.class);

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	@Option(names = { "-o", "--output" }, description = "Output File", required = true)
	private String outputFile;

	PartnerConnection connection;

	private String[] objecliypes;

	@Override
	public Integer call() {
		logger.info("cli describe was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();

			this.connection = CommonUtil.connect(this.username, this.password, this.serviceEndPoint);

			this.describe();

		} catch (final Exception cex) {
			logger.error("cli describe failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.objecliypes = config.getStringArray("objecliypes");

		for (final String element : this.objecliypes) {
			logger.info("objecliypes:" + element);
		}

	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}


	private void describeSObjectSample(CSVPrinter csvPrinter,String objecliype) throws Exception {
		
		DescribeSObjectResult describeSObjectResult = connection.describeSObject(objecliype);
		if (describeSObjectResult != null) {
			String name = describeSObjectResult.getName();			
			Field[] fields = describeSObjectResult.getFields();
			for (int i = 0; i < fields.length; i++) {
				Field field = fields[i];
				csvPrinter.printRecord(extracted2(name, field));
			}
		}
		

	}

	private ArrayList<String> extracted2(String name, Field field) {
		ArrayList<String> values = new ArrayList<String>();
		values.add(name);
		
		values.add(field.getName());
		values.add(field.getLabel());
		values.add(String.format("%d", field.getLength()));
		values.add(String.format("%s", field.getType()));
		
		String temp = "";

		if (field.getType().equals(FieldType.picklist)) {

			PicklistEntry[] picklistValues = field.getPicklistValues();
			if (picklistValues != null) {

				for (int j = 0; j < picklistValues.length; j++) {
					if (picklistValues[j].getLabel() != null) {
						temp = temp +  picklistValues[j].getLabel() + ";" ;
					}
				}
			}

		} else {
			if (field.getType().equals(FieldType.reference)) {
				String[] referenceTos = field.getReferenceTo();
				for (int j = 0; j < referenceTos.length; j++) {
					temp = temp +  referenceTos[j] + ";";
				}
			}
		}
		values.add(temp);
		return values;
	}

	private void describe() throws Exception {

		final BufferedWriter writer = Files.newBufferedWriter(Paths.get(this.outputFile));
		final CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("Object", "Field name",
				"Field label", "Field length", "Field type", "Field values"));

		for (final String objecliype : this.objecliypes) {
			this.describeSObjectSample(csvPrinter, objecliype);
		}

		csvPrinter.flush();
		csvPrinter.close();
	}
}
