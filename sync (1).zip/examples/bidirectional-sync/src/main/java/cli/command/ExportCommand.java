package cli.command;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "export", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class ExportCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(ExportCommand.class);

	public static String getCurrentDate() {
		return Instant.now().atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_LOCAL_DATE);
	}

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	PartnerConnection connection;
	@Option(names = { "-o", "--output" }, description = "Output Directory", required = true)
	private File outputFile;

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	private String[] queries;

	private String[] queryValues;

	@Override
	public Integer call() {
		logger.info("cli export was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();
			this.connection = CommonUtil.connect(this.username, this.password, this.serviceEndPoint);
			for (int i = 0; i < this.queries.length; i++) {
				this.extractExcel(this.queries[i], this.queryValues[i]);
			}

		} catch (final Exception cex) {
			logger.error("cli export failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.queries = config.getStringArray("queries");

		this.queryValues = new String[this.queries.length];

		for (int i = 0; i < this.queries.length; i++) {
			logger.info("queries:" + this.queries[i]);
			this.queryValues[i] = config.getString(this.queries[i]);
			logger.info("queryValues:" + this.queryValues[i]);
		}
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private void extractExcel(String soqlQueryName, String soqlQuery)
			throws ConnectionException, IOException, SQLException {

		final String fileName = soqlQueryName + "_" + getCurrentDate() + ".csv";

		QueryResult qr = this.connection.query(soqlQuery);
		boolean done = false;
		if (qr.getSize() > 0) {
			logger.info("Number for Records:{}", qr.getSize());
			final String headerStrings = StringUtils.substringBetween(soqlQuery.toUpperCase(), "SELECT", "FROM");
			final String[] headerStringsParsed = headerStrings.split(",");
			final BufferedWriter writer = new BufferedWriter(new FileWriter(new File(this.outputFile, fileName)));
			final CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader(headerStringsParsed));

			int rowCount = 0;
			while (!done) {
				final SObject[] records = qr.getRecords();
				if (logger.isDebugEnabled()) {
					logger.info("Writing:{} Records", records.length);
				}
//				rowCount = CommonUtil.printRecords(records, csvPrinter, rowCount + 1);

				if (qr.isDone()) {
					done = true;
				} else {
					qr = this.connection.queryMore(qr.getQueryLocator());
				}
			}

			csvPrinter.close();
		} else {
			logger.info("No records found.", qr.getSize());
		}

	}
}
