package cli.command;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.async.AsyncApiException;
import com.sforce.async.BatchInfo;
import com.sforce.async.BatchStateEnum;
import com.sforce.async.BulkConnection;
import com.sforce.async.ConcurrencyMode;
import com.sforce.async.ContentType;
import com.sforce.async.JobInfo;
import com.sforce.async.JobStateEnum;
import com.sforce.async.OperationEnum;
import com.sforce.async.QueryResultList;
import com.sforce.ws.ConnectionException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "bulkexport", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class BulkExportCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(BulkExportCommand.class);

	public static String getCurrentDate() {
		return Instant.now().atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_LOCAL_DATE);
	}

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	private String[] queries;

	private String[] tables;
	private String[] queryValues;
	@Option(names = { "-o", "--output" }, description = "Output Directory", required = true)
	private File outputFile;

	BulkConnection bulkConnection;

	@Override
	public Integer call() {
		logger.info("cli export was called with input {}", this.configFile.toPath());

		try {

			this.configureAuth();

			this.configure();
			this.bulkConnection = CommonUtil.bulkConnect(this.username, this.password, this.serviceEndPoint);

			for (int i = 0; i < this.queries.length; i++) {
				try {
					this.retrieveBulkData(this.queries[i], this.queryValues[i], this.tables[i]);
				} catch (final Exception e) {
					logger.error("Error Occurred while extracting: " + this.queries[i] + " :" + e);
					e.printStackTrace();
				}
			}

		} catch (final Exception cex) {
			logger.error("cli export failed", cex);
			return 34;
		}

		return 0;
	}

	private void closeJob(BulkConnection connection, String jobId) throws AsyncApiException {
		final JobInfo job = new JobInfo();
		job.setId(jobId);
		job.setState(JobStateEnum.Closed);
		connection.updateJob(job);
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.queries = config.getStringArray("queries");
		this.tables = config.getStringArray("tables");
		this.queryValues = new String[this.queries.length];

		for (int i = 0; i < this.queries.length; i++) {
			logger.info("queries:" + this.queries[i]);
			this.queryValues[i] = config.getString(this.queries[i]);
			logger.info("queryValues:" + this.queryValues[i]);
		}
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private JobInfo createJob(String sobjecliype, BulkConnection bulkconnection) throws AsyncApiException {
		JobInfo job = new JobInfo();
		job.setObject(sobjecliype);
		job.setOperation(OperationEnum.query);
		job.setConcurrencyMode(ConcurrencyMode.Parallel);
		job.setContentType(ContentType.CSV);
		job = bulkconnection.createJob(job);
		assert job.getId() != null;
		job = bulkconnection.getJobStatus(job.getId());
		return job;
	}

	private InputStream getData(String query, BulkConnection bulkConnection, JobInfo job) {
		InputStream inputStream = null;
		try {
			BatchInfo info = null;
			final ByteArrayInputStream bout = new ByteArrayInputStream(query.getBytes());
			info = bulkConnection.createBatchFromStream(job, bout);
			String[] queryResults = null;
			QueryResultList list = null;
			// int count = 0;
			for (int i = 0; i < 10000; i++) // 10000=maxRowsPerBatch
			{
				// count++;
				Thread.sleep(i == 0 ? 5 * 1000 : 5 * 1000);
				info = bulkConnection.getBatchInfo(job.getId(), info.getId());
				// If Batch Status is Completed,get QueryResultList and store in
				// queryResults.
				if (info.getState() == BatchStateEnum.Completed) {
					list = bulkConnection.getQueryResultList(job.getId(), info.getId());
					queryResults = list.getResult();

					break;
				} else if (info.getState() == BatchStateEnum.Failed) {
					logger.error("Batch failed: " + info);
					break;
				} else {
					logger.info("Batch is waiting: " + info);
				}
			}
			if (queryResults != null) {
				for (final String resultId : queryResults) {
					inputStream = bulkConnection.getQueryResultStream(job.getId(), info.getId(), resultId);
				}
			}

		} catch (final Exception aae) {
			logger.error(aae.getMessage());
		}
		return inputStream;
	}

	private void retrieveBulkData(String soqlQueryName, String query, String table)
			throws ConnectionException, AsyncApiException, FileNotFoundException, IOException, SQLException {

		final String fileName = soqlQueryName + "_" + getCurrentDate() + ".csv";

		final JobInfo job = this.createJob(table, this.bulkConnection);
		final InputStream inputStream = this.getData(query, this.bulkConnection, job);
		this.closeJob(this.bulkConnection, job.getId());

		final byte[] buffer = new byte[inputStream.available()];
		inputStream.read(buffer);

		final File targetFile = new File(this.outputFile, fileName);

		try (OutputStream outputStream = new FileOutputStream(targetFile)) {
			IOUtils.copy(inputStream, outputStream);
			outputStream.flush();
			outputStream.close();
		} catch (final FileNotFoundException e) {
			// handle exception here
		} catch (final IOException e) {
			// handle exception here
		}

		System.out.println("FileName::" + fileName);

	}
}
