package cli.command;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.ChannelSftp.LsEntrySelector;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "celrsftp", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class SFTPCommand implements Callable<Integer> {

	private static final String DATE = "Date";
	private static final String FILE_NAME = "FileName";
	private static final String DD_MM_YYYY_HH_MM_SS = "dd-MM-yyyy hh:mm:ss";
	static Logger logger = LoggerFactory.getLogger(LoadCommand.class);
	private static final String SFTP = "sftp";
	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	@Option(names = { "-d", "--download" }, description = "download the file")
	private final Boolean download = false;

	@Option(names = { "-l", "--list" }, description = "list files in a directory")
	private final Boolean list = false;

	private String[] localDownloadFilePaths;
	private String[] localUploadFilePaths;

	private String password;
	private final int port = 22;
	private String[] remoteFilePaths;
	private String sftphost;
	Session sftpSession;
	private String downloadLogPath;
	private String uploadLogPath;

	@Option(names = { "-u", "--upload" }, description = "Upload the file")
	private final Boolean upload = false;

	private String username;

	@Override
	public Integer call() {
		logger.info("celrsftp was called with input {}", this.configFile.toPath());

		try {
			this.configure();
			this.sftpSession = CommonUtil.getSFTPConnectionSession(this.username, this.password, this.sftphost,
					this.port);

			if (this.upload && this.download && this.list) {
				logger.error("Please select only one command - upload (-u) or download (-d)");
			} else if (this.upload) {
				this.perfromUpload();
			} else if (this.download) {
				this.performDownload();
			} else if (this.list) {
				this.list();
			}

		} catch (final Exception cex) {
			logger.error("celrsftp load failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.sftphost = config.getString("sftphost");
		this.remoteFilePaths = config.getStringArray("remoteFilePaths");
		this.localDownloadFilePaths = config.getStringArray("localDownloadFilePaths");
		this.localUploadFilePaths = config.getStringArray("localUploadFilePaths");
		this.downloadLogPath = config.getString("downloadLogPath");
		this.uploadLogPath = config.getString("uploadLogPath");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("sftphost:" + this.sftphost);

		for (int i = 0; i < this.localDownloadFilePaths.length; i++) {
			logger.info("remoteFilePath:" + this.remoteFilePaths[i]);
			logger.info("localFilePath:" + this.localDownloadFilePaths[i]);
		}

	}

	@SuppressWarnings("resource")
	private boolean fileExistInLogFile(String downloadLogPath, String fileName) {
		boolean fileExist = false;

		Reader reader;
		CSVParser csvParser;

		try {
			reader = Files.newBufferedReader(Paths.get(downloadLogPath));
			csvParser = new CSVParser(reader,
					CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());

			for (final CSVRecord csvRecord : csvParser) {
				// Accessing values by Header names
				final String name = csvRecord.get(FILE_NAME);

				if (name.equalsIgnoreCase(fileName)) {
					fileExist = true;
					break;
				}
			}

			csvParser.close();
			reader.close();

		} catch (final IOException e) {
			logger.info("No log file exist {}", fileName);
		}

		return fileExist;
	}

	private void list() {
		if (this.sftpSession != null) {
			ChannelSftp channel;
			try {
				channel = (ChannelSftp) this.sftpSession.openChannel(SFTP);
				channel.connect();

				for (int i = 0; i < this.remoteFilePaths.length; i++) {

					logger.info("Listing {}", this.remoteFilePaths[i]);
					channel.cd(this.remoteFilePaths[i]);
					LsEntrySelector selector = new LsEntrySelector() {
						public int select(LsEntry entry) {
							logger.info("{}", entry.toString());

							return CONTINUE;
						}
					};
					channel.ls(this.remoteFilePaths[i], selector);
				}

				channel.disconnect();
				this.sftpSession.disconnect();

			} catch (final JSchException e) {
				logger.error("Error connecting sftp server", e);
			} catch (final SftpException e) {
				logger.error("Error connecting sftp server", e);
			}
		} else {
			logger.error("sftp session error - no connection to sftp");
		}
	}

	private void logFileDetails(String filePath, String fileName) throws IOException {
		final File file = new File(filePath);
		final boolean fileExists = file.exists();
		final boolean append = true;
		final CSVFormat csvFormat = CSVFormat.DEFAULT;

		final OpenOption[] openOptions = append
				? new OpenOption[] { StandardOpenOption.CREATE, StandardOpenOption.APPEND }
				: new OpenOption[] { StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING };

		final Writer writer = new OutputStreamWriter(Files.newOutputStream(file.toPath(), openOptions),
				StandardCharsets.UTF_8);
		final CSVPrinter printer = append && fileExists ? csvFormat.print(writer)
				: csvFormat.withHeader(FILE_NAME, DATE).print(writer);

		printer.printRecord(fileName, new SimpleDateFormat(DD_MM_YYYY_HH_MM_SS).format(new Date()));
		printer.close();
		writer.close();
	}

	private void performDownload() {
		if (this.sftpSession != null) {
			ChannelSftp channel;

			try {
				channel = (ChannelSftp) this.sftpSession.openChannel(SFTP);
				channel.connect();

				for (int i = 0; i < this.localDownloadFilePaths.length; i++) {
					logger.info("Downloading {}", this.remoteFilePaths[i]);

					final Vector<?> filelist = channel.ls(this.remoteFilePaths[i]);
					for (final Object element : filelist) {
						final LsEntry entry = (LsEntry) element;
						final String filePath = this.remoteFilePaths[i] + entry.getFilename();
						logger.info("file Path : " + filePath);

						if (!this.fileExistInLogFile(this.downloadLogPath, filePath)) {
							channel.get(filePath, this.localDownloadFilePaths[i]);
							this.logFileDetails(this.downloadLogPath, filePath);
							logger.info("file {} downloaded successfully", filePath);

						} else {
							logger.info("File {} already downloaded earlier. No download action needed", filePath);
						}
					}
				}

				channel.disconnect();
				this.sftpSession.disconnect();

			} catch (final JSchException e) {
				logger.error("Error connecting sftp server", e);
			} catch (final SftpException e) {
				logger.error("Error connecting sftp server", e);
			} catch (final IOException e) {
				logger.error("Error connecting sftp server", e);
			}

		} else {
			logger.error("sftp session error - no connection to sftp");
		}
	}

	private void perfromUpload() {
		if (this.sftpSession != null) {
			ChannelSftp channel;
			try {
				channel = (ChannelSftp) this.sftpSession.openChannel(SFTP);
				channel.connect();
				for (int i = 0; i < this.localUploadFilePaths.length; i++) {

					final File[] files = new File(this.localUploadFilePaths[i]).listFiles();

					for (final File file : files) {
						if (file.isFile()) {
							final String filePath = this.localUploadFilePaths[i] + file.getName();
							logger.info("Uploading {}", filePath);

							if (!this.fileExistInLogFile(this.uploadLogPath, filePath)) {
								channel.put(filePath, this.remoteFilePaths[i]);
								this.logFileDetails(this.uploadLogPath, filePath);
								logger.info("file {} uploaded successfully", filePath);
							} else {
								logger.info("File {} already uploaded earlier. No upload action needed", filePath);
							}
						}
					}
				}

				channel.disconnect();
				this.sftpSession.disconnect();

			} catch (final JSchException e) {
				logger.error("Error connecting sftp server", e);
			} catch (final SftpException e) {
				logger.error("Error connecting sftp server", e);
			} catch (final IOException e) {
				logger.error("Error connecting sftp server", e);
			}
		} else {
			logger.error("sftp session error - no connection to sftp");
		}
	}

}
