package cli.command;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Component;

import picocli.CommandLine;
import picocli.CommandLine.IFactory;

@Component

public class CLIRunner implements CommandLineRunner, ExitCodeGenerator {
	static Logger logger = LoggerFactory.getLogger(CLIRunner.class);
	private final CLICommand cliCommand;

    @Autowired
    IFactory factory;
   
    
	//private final IFactory factory; // auto-configured to inject PicocliSpringFactory

	private int exitCode;

	public CLIRunner(CLICommand cliCommand, IFactory factory) {
		this.cliCommand = cliCommand;
		this.factory = factory;
	}

	@Override
	public int getExitCode() {
		return this.exitCode;
	}

	@Override
	public void run(String... args) throws Exception {
		final long startTime0 = System.nanoTime();
		this.exitCode = new CommandLine(this.cliCommand, this.factory).execute(args);
		logger.info("Completed in: " + ((System.nanoTime() - startTime0) / 1e+9) + " Seconds");
	}
}
