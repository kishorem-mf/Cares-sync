package cli.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;

import cli.service.TransformationService;
import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "transform", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class TransformCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(TransformCommand.class);
	private static final String DD_MM_YYYY = "dd-MM-yyyy";

	public static String getCurrentDate() {
		return Instant.now().atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_LOCAL_DATE);
	}

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	PartnerConnection connection;

	@Option(names = { "-o", "--output" }, description = "Output CSV File", required = true)
	private File outputFile;

	@Option(names = { "-f", "--file" }, description = "Read input from CSV file")
	private final Boolean csvFileInput = false;

	private String query;
	private String inputdatafile;
	private String mappingfile;
	private String filename;
	private List<CSVRecord> mapping;

	private String[] headers;
	@Autowired
	TransformationService transformationService;

	@Override
	public Integer call() {
		logger.info("cli transform was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();
			this.loadMapping();
			this.connection = CommonUtil.connect(this.username, this.password, this.serviceEndPoint);
			if (csvFileInput) {
				this.transformFile(new File(this.inputdatafile));
			} else {
				this.transform(this.query);
			}

		} catch (final Exception cex) {
			logger.error("cli transform failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.filename = config.getString("filename");
		if (this.filename!=null && !this.filename.trim().equals("")) {
			this.filename = filename + "_" + new SimpleDateFormat(DD_MM_YYYY).format(new Date()) +".csv";
		}
		this.query = config.getString("query");
		this.mappingfile = config.getString("mapping");
		this.inputdatafile = config.getString("inputdata");

		logger.info("query:" + this.query);

	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private String[] getHeaders() { // TODO Auto-generated method stub
		if (this.headers == null) {
			this.headers = this.mapping.stream().map(e -> e.get(0)).toArray(String[]::new);
		}
		return this.headers;
	}

	private void loadMapping() throws FileNotFoundException, IOException {
		logger.info("Loading Mapping");
		final Reader reader = new BufferedReader(new FileReader(this.mappingfile));
		final CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());

		this.mapping = csvParser.getRecords();

		csvParser.close();
	}

	private void transform(String soqlQuery) throws ConnectionException, IOException, SQLException {

		QueryResult qr = this.connection.query(soqlQuery);
		boolean done = false;
		if (qr.getSize() > 0) {
			logger.info("Number for Records:{}", qr.getSize());

			final BufferedWriter writer = new BufferedWriter(new FileWriter(new File(this.outputFile,filename)));
			final CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader(this.getHeaders()));

			int rowCount = 0;
			while (!done) {
				final SObject[] records = qr.getRecords();
				logger.info("Writing:{} Records", records.length);

				rowCount = CommonUtil.printRecords(records, this.mapping, this.transformationService, csvPrinter,
						rowCount + 1);

				if (qr.isDone()) {
					done = true;
				} else {
					qr = this.connection.queryMore(qr.getQueryLocator());
				}
			}

			csvPrinter.close();
		} else {
			logger.info("No records found.", qr.getSize());
		}

	}

	private void transformFile(File file) throws IOException {
		final BufferedWriter writer = new BufferedWriter(new FileWriter(new File(this.outputFile,filename)));
		final CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader(this.getHeaders()));

		final Reader reader = new BufferedReader(new FileReader(file));
		final CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
		final Iterator<CSVRecord> iter = csvParser.iterator();
		CSVRecord record = null;
		while (iter.hasNext()) {
			record = iter.next();
			CommonUtil.printRecord(record, this.mapping, this.transformationService, csvPrinter);
		}
		csvParser.close();
		csvPrinter.close();
	

	}
}
