package cli.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.Error;
import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.SaveResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "load", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class LoadCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(LoadCommand.class);

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	@Option(names = { "-k", "--chunk" }, description = "Number of records in chunks")
	private final Integer chunk = 100;

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	@Option(names = { "-l", "--limit" }, description = "Number of records")
	private final Integer limit = -1;

	@Option(names = { "-e", "--errors" }, description = "Process Errors")
	private final Boolean processErrors = false;

	@Option(names = { "-v", "--validate" }, description = "Perform Validation and reject record if validation fails")
	private final Boolean validate = false;

	@Option(names = { "-f", "--formatted" }, description = "Treat dates as preformatted")
	private final Boolean formatted = false;

	PartnerConnection connection;

	private String[] dateTimeFormat;

	private String[] dateTimeMillisFormat;

	private String[] dateFormat;

	private String developerName;
	List<Integer> errorRecordNumberList = null;
	List<LoadResultError> errors = null;
	private String[] fixed;
	private String[] fixedValues;
	private String inputdatafile;
	List<String> mapping;

	private String mappingfile;
	private String objecliype;
	private String recordTypeId;

	private String resultfile;

	private void addError(long j, Error err) {
		this.addError(j, err.getStatusCode().toString(), err.getMessage());
	}

	private void addError(long j, String errorCode, String errorMessage) {
		if (this.errors == null) {
			this.errors = new ArrayList<>();
		}

		final LoadResultError error = new LoadResultError();
		error.setRecordNumber(j + 1);
		error.setErrorCode(errorCode);
		error.setErrorMessage(errorMessage);

		// add to error list
		this.errors.add(error);
	}

	@Override
	public Integer call() {
		logger.info("cli load was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();
			this.loadMapping();
			this.connection = CommonUtil.connect(this.username, this.password, this.serviceEndPoint);
			this.recordTypeId = this.getRecordTypeId();
			this.loadData();

		} catch (final Exception cex) {
			logger.error("cli load failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.inputdatafile = config.getString("inputdata");
		this.mappingfile = config.getString("mapping");
		this.resultfile = config.getString("result");
		this.objecliype = config.getString("objecliype");
		this.developerName = config.getString("DeveloperName");
		this.dateFormat = config.getStringArray("dateFormat");
		this.dateTimeFormat = config.getStringArray("dateTimeFormat");
		this.dateTimeMillisFormat = config.getStringArray("dateTimeMillisFormat");
		this.fixed = config.getStringArray("fixed");
		this.fixedValues = new String[this.fixed.length];

		logger.info("inputdata:" + this.inputdatafile);
		logger.info("mapping:" + this.mappingfile);
		logger.info("result:" + this.resultfile);
		logger.info("objecliype:" + this.objecliype);
		logger.info("DeveloperName:" + this.developerName);

		for (final String element : this.dateFormat) {
			logger.info("dateFormat:" + element);
		}

		for (final String element : this.dateTimeFormat) {
			logger.info("dateFormat:" + element);
		}

		for (final String element : this.dateTimeMillisFormat) {
			logger.info("dateFormat:" + element);
		}

		for (int i = 0; i < this.fixed.length; i++) {
			logger.info("fixed:" + this.fixed[i]);
			this.fixedValues[i] = config.getString(this.fixed[i]);
			logger.info("fixedValues:" + this.fixedValues[i]);
		}
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private void createSObjects(List<SObject> sObjects) throws ConnectionException, IOException {
		SObject[] sobjectAR = new SObject[sObjects.size()];
		sobjectAR = sObjects.toArray(sobjectAR);

		final SaveResult[] results = this.connection.create(sobjectAR);

		for (int j = 0; j < results.length; j++) {
			// write results to CSV file

			if (results[j].isSuccess()) {
				logger.info("SObject created with an ID of {}: ", results[j].getId());
			} else {
				for (int i = 0; i < results[j].getErrors().length; i++) {
					final com.sforce.soap.partner.Error err = results[j].getErrors()[i];
					logger.error("Errors were found on item {} Error code is {} Error message {}", j,
							err.getStatusCode(), err.getMessage());

					this.addError(j, err);
				}
			}
		}

	}

	private String getRecordTypeId() throws ConnectionException {
		if ((this.developerName != null) && (this.objecliype != null)) {
			final QueryResult qr = this.connection
					.query(String.format("SELECT Id  FROM RecordType where DeveloperName='%s' and SObjecliype ='%s'",
							this.developerName, this.objecliype));
			final SObject[] records = qr.getRecords();
			if (records.length != 0) {
				return records[0].getId();
			}
		}
		return null;
	}

	private boolean isRecordExsitInErrorList(int index) throws IOException {
		if (this.errorRecordNumberList == null) {
			this.loadErrorRecordNumbers();
		}

		return this.errorRecordNumberList.contains(index);
	}

	private void loadData() throws FileNotFoundException, IOException, ConnectionException {

		logger.info("Loading Data");
		final Reader reader = new BufferedReader(new FileReader(new File(this.inputdatafile)));
		final CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
		final Iterator<CSVRecord> iter = csvParser.iterator();

		int index = 1;

		List<SObject> sObjects = new ArrayList<>();
		boolean processRecord = true;

		while (iter.hasNext()) {
			final CSVRecord record = iter.next();

			if (this.processErrors) {
				if (!this.isRecordExsitInErrorList(index)) {
					processRecord = false;
				} else {
					processRecord = true;
				}
			}

			if (processRecord) {
				this.processRecords(sObjects, record);
			}
			if ((index % this.chunk) == 0) {
				this.createSObjects(sObjects);
				sObjects = new ArrayList<>();
			}

			if ((index % 1000) == 0) {
				logger.info("Processed {}:", index);
				// break;
			}
			if ((this.limit != -1) && ((index % this.limit) == 0)) {
				break;
			}

			index++;
		}

		csvParser.close();
		this.createSObjects(sObjects);
		this.updateErrorFile();
	}

	private void loadErrorRecordNumbers() throws IOException {
		if (this.errorRecordNumberList == null) {
			this.errorRecordNumberList = new ArrayList<>();

			final Reader reader = new BufferedReader(new FileReader(this.resultfile));
			final CSVParser csvParserERFile = new CSVParser(reader,
					CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
			final Iterator<CSVRecord> iterERFile = csvParserERFile.iterator();

			while (iterERFile.hasNext()) {
				final CSVRecord recordERFile = iterERFile.next();
				this.errorRecordNumberList.add(Integer.valueOf(recordERFile.get(0)));
			}

			csvParserERFile.close();
		}
	}

	private void loadMapping() throws FileNotFoundException, IOException {
		logger.info("Loading Mapping");
		final Reader reader = new BufferedReader(new FileReader(this.mappingfile));
		final CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
		final Iterator<CSVRecord> iter = csvParser.iterator();

		final CSVRecord record = iter.next();
		this.mapping = CommonUtil.getValues(record);

		csvParser.close();
	}

	private void processRecords(List<SObject> sObjects, CSVRecord record) {
		final SObject sObject = new SObject();
		sObject.setType(this.objecliype);

		try {
			for (int count = 0; count < this.mapping.size(); count++) {
				CommonUtil.setValue(sObject, this.mapping.get(count), record, count, this.validate, this.dateFormat,
						this.dateTimeFormat, this.dateTimeMillisFormat, this.formatted);
			}
			if (this.recordTypeId != null) {
				sObject.setField("RecordTypeId", this.recordTypeId);
			}

			for (int i = 0; i < this.fixed.length; i++) {
				sObject.setField(this.fixed[i], this.fixedValues[i]);
			}
			sObjects.add(sObject);
		} catch (final RuntimeException e) {
			this.addError(record.getRecordNumber(), "PROC", e.getMessage());
			logger.error(e.getMessage());
		}

	}

	private void updateErrorFile() throws IOException {
		if (this.errors != null) {
			final BufferedWriter writer = Files.newBufferedWriter(Paths.get(this.resultfile));
			final CSVPrinter csvPrinter = new CSVPrinter(writer,
					CSVFormat.DEFAULT.withHeader("Record#", "ErrorCode", "ErrorMessage"));

			for (final LoadResultError error : this.errors) {
				csvPrinter.printRecord(error.getRecordNumber(), error.getErrorCode(), error.getErrorMessage());
			}

			csvPrinter.flush();
			csvPrinter.close();
			logger.info("Updated errors in the csv file");
		} else {
			logger.info("No errors to log");
		}
	}

}
