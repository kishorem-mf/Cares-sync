package cli.command;

import java.io.File;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.async.BulkConnection;
import com.sforce.soap.metadata.MetadataConnection;
import com.sforce.soap.partner.PartnerConnection;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "testconnection", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class TestConnectionCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(TestConnectionCommand.class);
	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String authEndPoint;
	private String serviceEndPoint;
	private String username;
	private String password;
	private String clientId;
	private String clientSecret;
	private String oauthUrl;

	PartnerConnection partnerConnection;

	BulkConnection bulkConnection;
	MetadataConnection metadataConnection;
	String accessToken;

	@Override
	public Integer call() {
		logger.info("cli testconnection was called with input {}", this.authConfig.toPath());

		try {
			this.configureAuth();
			this.partnerConnection = CommonUtil.connect(username, password, authEndPoint);
			com.sforce.soap.partner.GetUserInfoResult userInfo = partnerConnection.getUserInfo();

			logger.info("UserID {}: ", userInfo.getUserId());
			logger.info("User Full Name{}: ", userInfo.getUserFullName());
			logger.info("User Email{}: ", userInfo.getUserEmail());

			this.bulkConnection = CommonUtil.bulkConnect(this.username, this.password, this.authEndPoint);
			this.metadataConnection = CommonUtil.metadataConnect(this.username, this.password, this.authEndPoint,
					this.serviceEndPoint);
			this.accessToken=CommonUtil.login(clientId, clientSecret, username, password, oauthUrl);

		} catch (final Exception cex) {
			logger.error("cli testconnection failed", cex);
			return 34;
		}

		return 0;
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
				.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
						.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");
		this.authEndPoint = config.getString("authEndPoint");
		this.clientId = config.getString("clientId");
		this.clientSecret = config.getString("clientSecret");
		this.oauthUrl = config.getString("oauthUrl");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);
		logger.info("authEndPoint:" + this.authEndPoint);
		logger.info("oauthUrl:" + this.oauthUrl);
		logger.info("clientId:" + this.clientId);
		logger.info("clientSecret:" + this.clientSecret);

	}

}
