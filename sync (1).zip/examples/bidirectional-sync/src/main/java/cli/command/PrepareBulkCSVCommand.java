package cli.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.math3.random.RandomDataGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.PartnerConnection;
import com.sforce.soap.partner.QueryResult;
import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.ConnectionException;

import cli.util.CommonUtil;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "prepare", mixinStandardHelpOptions = true, exitCodeOnExecutionException = 34)
public class PrepareBulkCSVCommand implements Callable<Integer> {

	static Logger logger = LoggerFactory.getLogger(PrepareBulkCSVCommand.class);

	@Option(names = { "-a", "--auth" }, description = "Auth Configuration File", required = true)
	private File authConfig;

	private String serviceEndPoint;
	private String username;
	private String password;

	@Option(names = { "-c", "--config" }, description = "Configuration File", required = true)
	private File configFile;

	@Option(names = { "-o", "--output" }, description = "Output Directory", required = true)
	private File outputFile;

	@Option(names = { "-v", "--validate" }, description = "Perform Validation and reject record if validation fails")
	private final Boolean validate = false;

	@Option(names = { "-f", "--formatted" }, description = "Treat dates as preformatted")
	private final Boolean formatted = false;

	PartnerConnection connection;

	private String[] dateTimeFormat;

	private String[] dateTimeMillisFormat;

	private String[] dateFormat;

	private String developerName;
	List<Integer> errorRecordNumberList = null;
	List<LoadResultError> errors = null;
	private String[] fixed;
	private String[] fixedValues;
	private String inputdatafile;
	List<String> mapping;

	private String mappingfile;
	private String objecliype;
	private String recordTypeId;
	private String resultfile;
	private String filename;
	
	private String[] cipher;
	private String[] random;
	RandomDataGenerator randomDataGenerator = new RandomDataGenerator();

	@Override
	public Integer call() {
		logger.info("cli prepare was called with input {}", this.configFile.toPath());

		try {
			this.configureAuth();
			this.configure();
			this.loadMapping();
			this.connection = CommonUtil.connect(this.username, this.password, this.serviceEndPoint);
			this.recordTypeId = this.getRecordTypeId();
			this.prepareData();

		} catch (final Exception cex) {
			logger.error("cli prepare failed", cex);
			return 34;
		}

		return 0;
	}

	private void configure() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.configFile));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.inputdatafile = config.getString("inputdata");
		this.mappingfile = config.getString("mapping");
		this.resultfile = config.getString("result");
		this.objecliype = config.getString("objecliype");
		this.filename = config.getString("filename");
		this.developerName = config.getString("DeveloperName");
		this.dateFormat = config.getStringArray("dateFormat");
		this.dateTimeFormat = config.getStringArray("dateTimeFormat");
		this.dateTimeMillisFormat = config.getStringArray("dateTimeMillisFormat");
		this.fixed = config.getStringArray("fixed");
		this.random = config.getStringArray("random");
		this.cipher = config.getStringArray("cipher");

		this.fixedValues = new String[this.fixed.length];

		logger.info("inputdata:" + this.inputdatafile);
		logger.info("mapping:" + this.mappingfile);
		logger.info("result:" + this.resultfile);

		logger.info("DeveloperName:" + this.developerName);

		for (final String element : this.dateFormat) {
			logger.info("dateFormat:" + element);
		}

		for (final String element : this.dateTimeFormat) {
			logger.info("dateFormat:" + element);
		}

		for (final String element : this.dateTimeMillisFormat) {
			logger.info("dateFormat:" + element);
		}

		for (int i = 0; i < this.fixed.length; i++) {
			logger.info("fixed:" + this.fixed[i]);
			this.fixedValues[i] = config.getString(this.fixed[i]);
			logger.info("fixedValues:" + this.fixedValues[i]);
		}
		
		for (int i = 0; i < this.random.length; i++) {
			logger.info("random:" + this.random[i]);
		
		}
		
		for (int i = 0; i < this.cipher.length; i++) {
			logger.info("cipher:" + this.cipher[i]);
		
		}
	}

	private void configureAuth() throws ConfigurationException {
		final Parameters params = new Parameters();
		final FileBasedConfigurationBuilder<PropertiesConfiguration> builder = new FileBasedConfigurationBuilder<>(
				PropertiesConfiguration.class)
						.configure(params.fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(','))
								.setFile(this.authConfig));

		final PropertiesConfiguration config = builder.getConfiguration();

		this.username = config.getString("username");
		this.password = config.getString("password");
		this.serviceEndPoint = config.getString("serviceEndPoint");

		logger.info("username:" + this.username);
		logger.info("password:" + this.password);
		logger.info("serviceEndPoint:" + this.serviceEndPoint);

	}

	private String getRecordTypeId() throws ConnectionException {
		if ((this.developerName != null) && (this.objecliype != null)) {
			final QueryResult qr = this.connection
					.query(String.format("SELECT Id  FROM RecordType where DeveloperName='%s' and SObjecliype ='%s'",
							this.developerName, this.objecliype));
			final SObject[] records = qr.getRecords();
			if (records.length != 0) {
				return records[0].getId();
			}
		}
		return null;
	}

	private void loadMapping() throws FileNotFoundException, IOException {
		logger.info("Loading Mapping");
		final Reader reader = new BufferedReader(new FileReader(this.mappingfile));
		final CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
		final Iterator<CSVRecord> iter = csvParser.iterator();

		final CSVRecord record = iter.next();
		this.mapping = CommonUtil.getValues(record);

		csvParser.close();
	}

	private void prepareData() throws FileNotFoundException, IOException, ConnectionException {

		logger.info("Preparing Data");
		final Reader reader = new BufferedReader(new FileReader(new File(this.inputdatafile)));
		final CSVParser csvParser = new CSVParser(reader,
				CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
		final Iterator<CSVRecord> iter = csvParser.iterator();
		final File out = new File(this.outputFile, this.filename);
		final BufferedWriter writer = new BufferedWriter(new FileWriter(out));
		final List<String> header = new ArrayList<>(this.mapping);

        if (cipher.length!=0) {
        	header.add(cipher[0]);
        }

		for (final String element : this.fixed) {
			header.add(element);
		}
		
		for (int i = 0; i < this.random.length; i++) {
			header.add(this.random[i]);
		}
		
		if (this.recordTypeId != null) {
			header.add(this.recordTypeId);
		}
		
		final CSVPrinter csvPrinter = new CSVPrinter(writer,
				CSVFormat.DEFAULT.withHeader(header.toArray(new String[header.size()])));

		while (iter.hasNext()) {
			final CSVRecord record = iter.next();
			final List<String> values = CommonUtil.getValues(record);

			for (int count = 0; count < this.mapping.size(); count++) {
				// String[] dateFormat, String[] dateTimeFormat, String[] dateTimeMillisFormat
				CommonUtil.setValues(values, this.mapping.get(count), record, count, this.validate, this.dateFormat,
						this.dateTimeFormat, this.dateTimeMillisFormat, this.formatted);
			}

	        if (cipher.length!=0) {
	        	int index = this.mapping.indexOf(cipher[1]);
	        	values.add(CommonUtil.cipher(values.get(index)));
	        }
	        
			for (int i = 0; i < this.fixed.length; i++) {
				values.add(this.fixedValues[i]);
			}
			
			for (int i = 0; i < this.random.length; i++) {
				values.add(this.getRandomInt());
			}

			if (this.recordTypeId != null) {
				values.add(this.recordTypeId);
			}

			csvPrinter.printRecord(values);

		}
		csvPrinter.close();
		csvParser.close();
	}

	private String getRandomInt() {
	
		return String.format("%d",randomDataGenerator.nextInt(1000000, 2000000));
	}

}
