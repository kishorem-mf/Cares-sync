package cli.transform;

import org.apache.commons.math3.random.RandomDataGenerator;
import org.springframework.stereotype.Component;

@Component
public class Random extends AbstractFieldTransformer {

	private static final String RANDOM = "Random";
	private static RandomDataGenerator randomDataGenerator = new RandomDataGenerator();

	@Override
	public String getTransformType() {
		return RANDOM;
	}

	@Override
	public String transform(String fieldValue, String... params) throws Exception {
		return  String.format("%d",randomDataGenerator.nextInt(1000000, 2000000));
	}

}
