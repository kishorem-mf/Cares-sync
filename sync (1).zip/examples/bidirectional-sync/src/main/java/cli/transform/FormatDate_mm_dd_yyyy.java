package cli.transform;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class FormatDate_mm_dd_yyyy extends AbstractFieldTransformer {
	
	private static final String FORMAT_DATE_MM_DD_YYYY = "FormatDate_mm_dd_yyyy";

	static Logger logger = LoggerFactory.getLogger(FormatDate_mm_dd_yyyy.class);

	@Override
	public String getTransformType() {
		return FORMAT_DATE_MM_DD_YYYY;
	}

	@Override
	public String transform(String fieldValue, String... params) throws ParseException {
		if ((fieldValue != null) && !fieldValue.isEmpty()) {
			fieldValue = DATE_FORMAT_MM_DD_YYYY.format(DATE_FORMAT_YYYY_MM_DD.parse(fieldValue));
		}
		return fieldValue;
	}

}
