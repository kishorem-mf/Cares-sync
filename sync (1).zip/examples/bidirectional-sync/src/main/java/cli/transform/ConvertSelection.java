package cli.transform;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.github.cliftonlabs.json_simple.JsonArray;
import com.github.cliftonlabs.json_simple.JsonException;
import com.github.cliftonlabs.json_simple.Jsoner;

@Component
public class ConvertSelection extends AbstractFieldTransformer {

	private static final String CONVERT_SELECTION = "ConvertSelection";

	@Override
	public String getTransformType() {

		return CONVERT_SELECTION;
	}

	@Override
	public String transform(String input, String... params) throws JsonException {
		String result = "";
		final String jsonRules = params[1];

		if ((jsonRules != null) && !jsonRules.isEmpty()) {
			final JsonArray ar = (JsonArray) Jsoner.deserialize(jsonRules);

			if (ar != null) {
				final int len = ar.size();
				for (int i = 0; i < len; i++) {
					final JsonArray param = (JsonArray) ar.get(i);
					if ((input != null) && (Arrays.stream(input.split(";")).map(String::toUpperCase)
							.collect(Collectors.toList()).contains(input.toUpperCase()))) {
						result = param.getString(1);
						break;
					}
				}
			}
		}

		return result;
	}

}
