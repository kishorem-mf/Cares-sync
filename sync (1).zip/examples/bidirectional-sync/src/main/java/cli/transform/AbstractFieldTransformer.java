package cli.transform;

import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sforce.soap.partner.sobject.SObject;
import com.sforce.ws.bind.XmlObject;

public abstract class AbstractFieldTransformer implements FieldTransformer {
	static Logger logger = LoggerFactory.getLogger(AbstractFieldTransformer.class);

	@Override
	public String getFirstParam(String... params) {
		final String fieldName = params[0].substring(params[0].lastIndexOf(".") + 1);
		return fieldName;
	}

	@Override
	public String transform(CSVRecord obj, String... params) {
		String fieldValue = null;

		if ((params != null) && (params.length > 0)) {
			final String fieldName = this.getFirstParam(params);

			if ((fieldName != null) && !fieldName.isEmpty()) {
				fieldValue = obj.get(fieldName);
				try {
					if (fieldValue != null) {
						fieldValue = this.transform(fieldValue, params);
					} else {
						fieldValue = "";
					}
				} catch (final Exception e) {
					logger.error("Error in processing transformation for field: " + fieldName, e);
				}
			}
		}

		return fieldValue;
	}

	@Override
	public String transform(SObject obj, String... params) {
		String fieldValue = null;

		if ((params != null) && (params.length > 0)) {
			final String fieldName = this.getFirstParam(params);

			if ((fieldName != null) && !fieldName.isEmpty()) {
				final XmlObject child = obj.getChild(fieldName);

				if (child != null) {
					fieldValue = (String) child.getValue();
					try {
						if (fieldValue != null) {
							fieldValue = this.transform(fieldValue, params);
						} else {
							fieldValue = "";
						}
					} catch (final Exception e) {
						logger.error("Error in processing transformation for field: " + fieldName, e);
					}
				}
			}
		}

		return fieldValue;
	}

	@Override
	public abstract String transform(String fieldValue, String... params) throws Exception;
}
