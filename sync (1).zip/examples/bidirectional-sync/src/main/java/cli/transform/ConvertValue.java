package cli.transform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.github.cliftonlabs.json_simple.JsonArray;
import com.github.cliftonlabs.json_simple.JsonException;
import com.github.cliftonlabs.json_simple.Jsoner;

@Component
public class ConvertValue extends AbstractFieldTransformer {

	private static final String CONVERT_VALUE = "ConvertValue";

	static Logger logger = LoggerFactory.getLogger(ConvertValue.class);

	@Override
	public String getTransformType() {

		return CONVERT_VALUE;
	}

	@Override
	public String transform(String input, String... params) throws JsonException {
		String result = "";
		final String jsonRules = params[1];

		if ((jsonRules != null) && !jsonRules.isEmpty()) {
			final JsonArray ar = (JsonArray) Jsoner.deserialize(jsonRules);

			if (ar != null) {
				final int len = ar.size();
				for (int i = 0; i < len; i++) {
					final JsonArray param = (JsonArray) ar.get(i);

					if ((input != null) && input.equalsIgnoreCase(param.getString(0))) {
						result = param.getString(1);
						break;
					}
				}
			}
		}

		return result;
	}

}
