package cli.transform;

import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;

@Component
public class Constant extends AbstractFieldTransformer {

	private static final String CONSTANT = "Const";

	@Override
	public String getTransformType() {

		return CONSTANT;
	}

	@Override
	public String transform(String fieldValue, String... params) throws Exception {

		return fieldValue;
	}

	@Override
	public String transform(CSVRecord obj, String... params) {
		String fieldValue = null;

		if ((params != null) && (params.length > 0)) {
			fieldValue= this.getFirstParam(params);
		}
		try {
			if (fieldValue != null) {
				fieldValue = this.transform(fieldValue, params);
			} else {
				fieldValue = "";
			}
		} catch (final Exception e) {
			logger.error("Error in processing transformation for field: " , e);
		}

		return fieldValue;
	}


}
