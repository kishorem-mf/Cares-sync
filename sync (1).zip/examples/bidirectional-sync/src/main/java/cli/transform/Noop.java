package cli.transform;

import org.springframework.stereotype.Component;

@Component
public class Noop extends AbstractFieldTransformer {

	private static final String NOOP = "Noop";

	@Override
	public String getTransformType() {

		return NOOP;
	}

	@Override
	public String transform(String fieldValue, String... params) throws Exception {

		return fieldValue;
	}

}
