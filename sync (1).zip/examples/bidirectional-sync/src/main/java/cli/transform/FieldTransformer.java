package cli.transform;

import java.text.SimpleDateFormat;

import org.apache.commons.csv.CSVRecord;

import com.sforce.soap.partner.sobject.SObject;

public interface FieldTransformer {

	static final String MM_DD_YYYY_String = "MM-dd-yyyy";
	static final String YYYY_MM_DD_String = "yyyy-MM-dd";

	static final SimpleDateFormat DATE_FORMAT_M_D_YYYY = new SimpleDateFormat("M/d/yyyy");

	static final SimpleDateFormat DATE_FORMAT_MM_DD_YYYY = new SimpleDateFormat(MM_DD_YYYY_String);
	static final SimpleDateFormat DATE_FORMAT_YYYY_MM_DD = new SimpleDateFormat(YYYY_MM_DD_String);
	
	String getFirstParam(String... params);

	String getTransformType();

	String transform(CSVRecord obj, String... params);

	String transform(SObject obj, String... params);

	String transform(String fieldValue, String... params) throws Exception;

}
