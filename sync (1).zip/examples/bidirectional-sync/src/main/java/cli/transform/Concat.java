package cli.transform;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.github.cliftonlabs.json_simple.JsonArray;
import com.github.cliftonlabs.json_simple.JsonException;
import com.github.cliftonlabs.json_simple.Jsoner;

@Component
public class Concat extends AbstractFieldTransformer {

	private static final String CONCAT = "Concat";

	@Override
	public String getTransformType() {

		return CONCAT;
	}

	@Override
	public String transform(String fieldValue, String... params) throws Exception {

		return fieldValue;
	}

	@Override
	public String transform(CSVRecord obj, String... params) {

		String result = "";
		final String jsonRules = params[1];
		if ((jsonRules != null) && !jsonRules.isEmpty()) {
			JsonArray ar;
			try {
				ar = (JsonArray) Jsoner.deserialize(jsonRules);
				if (ar != null) {

					String date = obj.get(ar.getString(0));
					String time = obj.get(ar.getString(1));
					Date temp = FieldTransformer.DATE_FORMAT_M_D_YYYY.parse(date);
					date = FieldTransformer.DATE_FORMAT_YYYY_MM_DD.format(temp);
					if (time != null && !time.trim().equals("")) {
						result = date + "T" + StringUtils.leftPad(time, 5, '0') + ":00";
					} else {
						result = date + "T" + "00:00:00";
					}
				}
			} catch (JsonException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return result;
	}
}
