package cli.transform;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class FormatDate_YYYY_MM_DD extends AbstractFieldTransformer {
	
	private static final String FormatDate_YYYY_MM_DD = "FormatDate_YYYY_MM_DD";

	static Logger logger = LoggerFactory.getLogger(FormatDate_YYYY_MM_DD.class);

	@Override
	public String getTransformType() {
		return FormatDate_YYYY_MM_DD;
	}

	@Override
	public String transform(String fieldValue, String... params) throws ParseException {
		if ((fieldValue != null) && !fieldValue.isEmpty()) {
			fieldValue = DATE_FORMAT_YYYY_MM_DD.format(DATE_FORMAT_M_D_YYYY.parse(fieldValue));
		}
		return fieldValue;
	}

}
