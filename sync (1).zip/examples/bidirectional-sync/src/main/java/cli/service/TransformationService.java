package cli.service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sforce.soap.partner.sobject.SObject;

import cli.transform.FieldTransformer;

@Component
public class TransformationService {
	private final Map<String, FieldTransformer> transformerMap;

	@Autowired
	public TransformationService(List<FieldTransformer> transformers) {
		this.transformerMap = transformers.stream()
				.collect(Collectors.toMap(FieldTransformer::getTransformType, Function.identity()));
	}

	public String transform(String transformType, CSVRecord record, String... params) {
		if ((transformType == null) || transformType.trim().equals("")) {
			return "";
		}

		final FieldTransformer transformer = this.transformerMap.get(transformType);
		return transformer.transform(record, params);

	}

	public String transform(String transformType, SObject obj, String... params) {
		if ((transformType == null) || transformType.trim().equals("")) {
			return "";
		}

		final FieldTransformer transformer = this.transformerMap.get(transformType);
		return transformer.transform(obj, params);

	}
}
