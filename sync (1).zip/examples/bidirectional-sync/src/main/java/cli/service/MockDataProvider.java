package cli.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class MockDataProvider {

	Map<String, CSVRecord> idMap = new HashMap<>();

	List<CSVRecord> mockRecords;

	int nextRecord = 0;

	public MockDataProvider(File mockFile) throws FileNotFoundException, IOException {
		super();
		final Reader reader = new BufferedReader(new FileReader(mockFile));

		final CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader().withTrim());
		this.mockRecords = csvParser.getRecords();

		csvParser.close();
	}

	public CSVRecord getMockRecord(String id) {
		CSVRecord record = this.idMap.get(id);
		if (record == null) {
			record = this.selectMockRecord();
			this.idMap.put(id, record);
		}
		return record;
	}

	private CSVRecord selectMockRecord() {
		if (this.nextRecord < this.mockRecords.size()) {
			final CSVRecord record = this.mockRecords.get(this.nextRecord);
			this.nextRecord++;
			return record;
		}
		return null;
	}
}
