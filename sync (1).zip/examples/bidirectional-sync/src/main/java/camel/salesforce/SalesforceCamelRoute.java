package camel.salesforce;


import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.salesforce.dto.QueryRecordsAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import software.amazon.awssdk.services.kinesis.KinesisClient;

	@Component
	public class SalesforceCamelRoute extends RouteBuilder {
		//@Autowired private KinesisClient kinesisClient;

	    @Override
	    public void configure() throws Exception {

//	    	
//	    	 from("aws-kinesis://{{stream}}?accessKey={{accessKey}}&secretKey={{secretKey}}&region={{region}}")
//	            .log("${body}");

	    	from("timer:hello?period=5000")
	    	   
	            .to("salesforce:query?sObjectQuery=SELECT+Id,Name+FROM+Account&format=JSON&sObjectClass=" + QueryRecordsAccount.class.getName())
	            .log("${body}")
	        	.to("stream:out");
	    }
	}


